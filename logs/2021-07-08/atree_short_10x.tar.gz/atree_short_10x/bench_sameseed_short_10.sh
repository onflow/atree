#! /bin/bash
# we're not going to use -test.count here because this is easier to view for relative diff between array size and perf 
time ./atree_sameseed.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_sameseed_short_01.log
time ./atree_sameseed.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_sameseed_short_02.log
time ./atree_sameseed.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_sameseed_short_03.log
time ./atree_sameseed.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_sameseed_short_04.log
time ./atree_sameseed.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_sameseed_short_05.log
time ./atree_sameseed.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_sameseed_short_06.log
time ./atree_sameseed.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_sameseed_short_07.log
time ./atree_sameseed.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_sameseed_short_08.log
time ./atree_sameseed.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_sameseed_short_09.log
time ./atree_sameseed.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_sameseed_short_10.log

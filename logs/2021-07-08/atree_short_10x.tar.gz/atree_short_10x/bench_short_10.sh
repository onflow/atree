#! /bin/bash
# we're not going to use -test.count here because this is easier to view for relative diff between array size and perf 
./atree.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_short_01.log
./atree.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_short_02.log
./atree.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_short_03.log
./atree.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_short_04.log
./atree.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_short_05.log
./atree.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_short_06.log
./atree.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_short_07.log
./atree.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_short_08.log
./atree.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_short_09.log
./atree.test -test.short -test.bench=. -test.benchmem -test.timeout=30m | tee atree_short_10.log
